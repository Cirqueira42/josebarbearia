// Telegram notification functions for José Barbearia

interface AppointmentData {
  id: number;
  customer_name: string;
  customer_phone: string;
  service_name: string;
  appointment_date: string;
  appointment_time: string;
}

// Format date for display (DD de mês de YYYY)
function formatDateLong(dateStr: string): string {
  const months = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
  const [year, month, day] = dateStr.split('-').map(Number);
  return `${day.toString().padStart(2, '0')} de ${months[month - 1]} de ${year}`;
}

// Format phone for WhatsApp link with pre-filled confirmation message
function formatWhatsAppLink(phone: string, appointment: AppointmentData): string {
  const cleanPhone = phone.replace(/\D/g, '');
  const fullPhone = cleanPhone.startsWith('55') ? cleanPhone : `55${cleanPhone}`;
  
  const formattedDate = formatDateLong(appointment.appointment_date);
  
  const confirmationMessage = `Olá ${appointment.customer_name}! 👋

Seu agendamento foi *CONFIRMADO* com sucesso! ✅

📅 *Data:* ${formattedDate}
🕐 *Horário:* ${appointment.appointment_time}
✂️ *Serviço:* ${appointment.service_name}

📍 *Local:*
Av. Otávio Rangel, 477 - Vila Cecap
Guariba - SP, 14845-106

🗺️ Ver no mapa:
https://maps.google.com/?q=Av.+Otávio+Rangel,+477+-+Vila+Cecap,+Guariba+-+SP

_Se precisar cancelar, clique aqui:_
https://e4id45fo46lti.mocha.app/api/appointments/${appointment.id}/cancel

Nos vemos em breve! 💈

_José Barbearia_`;

  return `https://wa.me/${fullPhone}?text=${encodeURIComponent(confirmationMessage)}`;
}

// Google Maps link for the barbershop address
const BARBERSHOP_ADDRESS = 'Av. Otávio Rangel, 477 - Guariba, SP';
const MAPS_LINK = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(BARBERSHOP_ADDRESS)}`;

/**
 * Send a notification to the barber via Telegram when a new appointment is created
 */
export async function sendTelegramNotificationToBarber(
  botToken: string,
  chatId: string,
  appointment: AppointmentData
): Promise<void> {
  const formattedDate = formatDateLong(appointment.appointment_date);
  const whatsappLink = formatWhatsAppLink(appointment.customer_phone, appointment);
  
  const message = `📅 *NOVO AGENDAMENTO #${appointment.id}*

👤 *Cliente:* ${appointment.customer_name}
📱 *Telefone:* ${appointment.customer_phone}

📅 *Data:* ${formattedDate}
🕐 *Horário:* ${appointment.appointment_time}
✂️ *Serviço:* ${appointment.service_name}

📍 *Local:*
Av. Otávio Rangel, 477 - Vila Cecap
Guariba - SP, 14845-106

🗺️ [Ver no Mapa](${MAPS_LINK})

💬 [Conversar no WhatsApp](${whatsappLink})`;

  const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
  
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      chat_id: chatId,
      text: message,
      parse_mode: 'Markdown',
      disable_web_page_preview: false,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    console.error('❌ Telegram API error:', error);
    throw new Error(`Telegram API error: ${response.status} - ${error}`);
  }

  const result = await response.json();
  console.log('✅ Telegram notification sent successfully:', result);
}

/**
 * Send a cancellation notification to the barber via Telegram
 */
export async function sendTelegramCancellationToBarber(
  botToken: string,
  chatId: string,
  appointment: AppointmentData
): Promise<void> {
  const formattedDate = formatDateLong(appointment.appointment_date);
  
  const message = `❌ *AGENDAMENTO CANCELADO #${appointment.id}*

👤 *Cliente:* ${appointment.customer_name}
📱 *Telefone:* ${appointment.customer_phone}

📅 *Data:* ${formattedDate}
🕐 *Horário:* ${appointment.appointment_time}
✂️ *Serviço:* ${appointment.service_name}

_Este horário agora está disponível para novos agendamentos._`;

  const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
  
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      chat_id: chatId,
      text: message,
      parse_mode: 'Markdown',
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    console.error('❌ Telegram cancellation API error:', error);
    throw new Error(`Telegram API error: ${response.status} - ${error}`);
  }

  console.log('✅ Telegram cancellation notification sent');
}
